<div class="testimonials-3 overview-bgi">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
        <div id="carouse3-example-generic" class="carousel slide" data-ride="carousel">
          <h1>Our Testimonial</h1>
          <div class="carousel-inner" role="listbox">
            <div class="item content clearfix active">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="avatar"> <img src="img/team.jpg" alt="avatar-1" class="img-responsive"> </div>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                  <div class="testimonials-info">
                    <div class="text"> <sup> <i class="fa fa-quote-left"></i> </sup> I liked the properties listed here, the properties listed here are they strong in build structure and maintenance of location is also too good. <sub> <i class="fa fa-quote-right"></i> </sub> </div>
                    <div class="author-name"> John Antony </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item content clearfix">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="avatar"> <img src="img/team.jpg" alt="avatar-2" class="img-responsive"> </div>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                  <div class="testimonials-info">
                    <div class="text"> <sup> <i class="fa fa-quote-left"></i> </sup> Very Good Properties,liked the interior part more. The properties listed here are they strong in build structure and maintenance of location is also too good. <sub> <i class="fa fa-quote-right"></i> </sub> </div>
                    <div class="author-name"> John Mery </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item content clearfix">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="avatar"> <img src="img/team.jpg" alt="avatar-4" class="img-responsive"> </div>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                  <div class="testimonials-info">
                    <div class="text"> <sup> <i class="fa fa-quote-left"></i> </sup> I liked the properties listed here, the properties listed here are they strong in build structure and maintenance of location is also too good. <sub> <i class="fa fa-quote-right"></i> </sub> </div>
                    <div class="author-name"> John Top </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="item content clearfix">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                  <div class="avatar"> <img src="img/team.jpg" alt="avatar-3" class="img-responsive"> </div>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12 ">
                  <div class="testimonials-info">
                    <div class="text"> <sup> <i class="fa fa-quote-left"></i> </sup> Very Good Properties,liked the interior part more. The properties listed here are they strong in build structure and maintenance of location is also too good. <sup> <i class="fa fa-quote-right"></i> </sup> </div>
                    <div class="author-name"> John Pitarshon </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <a class="left carousel-control" href="#carouse3-example-generic" role="button" data-slide="prev"> <span class="slider-mover-left t-slider-l" aria-hidden="true"> <i class="fa fa-angle-left"></i> </span> <span class="sr-only">Previous</span> </a> <a class="right carousel-control" href="#carouse3-example-generic" role="button" data-slide="next"> <span class="slider-mover-right t-slider-r" aria-hidden="true"> <i class="fa fa-angle-right"></i> </span> <span class="sr-only">Next</span> </a> </div>
      </div>
    </div>
  </div>
</div>