<div class="copy-right">
  <div class="container">
    <div class="row clearfix">
      <div class="col-md-8 col-sm-12"> &copy;  2018 Trademarks and brands are the property of their respective owners. </div>
      <div class="col-md-4 col-sm-12">
        <ul class="social-list clearfix">
          <li> <a href="#" class="facebook"> <i class="fa fa-facebook"></i> </a> </li>
          <li> <a href="#" class="twitter"> <i class="fa fa-twitter"></i> </a> </li>
          <li> <a href="#" class="linkedin"> <i class="fa fa-linkedin"></i> </a> </li>
          <li> <a href="#" class="google"> <i class="fa fa-google-plus"></i> </a> </li>
          <li> <a href="#" class="rss"> <i class="fa fa-rss"></i> </a> </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<script src="js/jquery-2.2.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap-submenu.js"></script>
<script src="js/rangeslider.js"></script>
<script src="js/jquery.mb.YTPlayer.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.scrollUp.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/leaflet.js"></script>
<script src="js/leaflet-providers.js"></script>
<script src="js/leaflet.markercluster.js"></script>
<script src="js/dropzone.js"></script>
<script src="js/jquery.filterizr.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/maps.js"></script>
<script src="js/app.js"></script>
<script src="js/ie10-viewport-bug-workaround.js"></script>
<script src="js/ie10-viewport-bug-workaround.js"></script>