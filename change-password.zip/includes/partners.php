<div class="partners-block">
  <div class="container">
    <h3>Brands & Partners</h3>
    <div class="row">
      <div class="col-md-12">
        <div class="carousel our-partners slide" id="ourPartners">
          <div class="carousel-inner">
            <div class="item active">
              <div class="col-xs-12 col-sm-6 col-md-3 partner-box"> <a href="#"> <img src="img/g4.png" alt="partner"> </a> </div>
            </div>
            <div class="item">
              <div class="col-xs-12 col-sm-6 col-md-3 partner-box"> <a href="#"> <img src="img/g4.png" alt="partner-2"> </a> </div>
            </div>
            <div class="item">
              <div class="col-xs-12 col-sm-6 col-md-3 partner-box"> <a href="#"> <img src="img/g4.png" alt="partner-3"> </a> </div>
            </div>
            <div class="item">
              <div class="col-xs-12 col-sm-6 col-md-3 partner-box"> <a href="#"> <img src="img/g4.png" alt="partner-4"> </a> </div>
            </div>
            <div class="item">
              <div class="col-xs-12 col-sm-6 col-md-3 partner-box"> <a href="#"> <img src="img/g4.png" alt="partner-5"> </a> </div>
            </div>
          </div>
          <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a> <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a> </div>
      </div>
    </div>
  </div>
</div>