<footer class="main-footer clearfix">
  <div class="container">
    <div class="footer-info">
      <div class="row">
        <div class="col-lg-4 col-md-3 col-sm-6 col-xs-12">
          <div class="footer-item">
            <div class="main-title-2">
              <h1>Contact Us</h1>
            </div>
            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's printing and </p>
            <ul class="personal-info">
              <li> <i class="fa fa-map-marker"></i> Address: 250 Yonge St, Suite 2201, Toronto, ON M5B 2L7, Canada </li>
              <li> <i class="fa fa-envelope"></i> Email:<a href="mailto:sales@canadalettings.com">sales@canadalettings.com</a> </li>
              <li> <i class="fa fa-phone"></i> Phone: <a href="tel:+1647 961 8625">+1647 961 8625</a> </li>
              <li> <i class="fa fa-fax"></i> Fax: +1647 961 8625 </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
          <div class="footer-item">
            <div class="main-title-2">
              <h1>Links</h1>
            </div>
            <ul class="links">
              <li> <a href="index.html">Home</a> </li>
              <li> <a href="#">About Us</a> </li>
              <li> <a href="#">Contact Us</a> </li>
              <li> <a href="#">Find Agent</a> </li>
              <li> <a href="#">properties for sale</a> </li>
              <li> <a href="#">properties to rent</a> </li>
              <li> <a href="#">properties for student</a> </li>
              <li> <a href="#">properties Details</a> </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
          <div class="footer-item popular-posts">
            <div class="main-title-2">
              <h1>Popular Posts</h1>
            </div>
            <div class="media">
              <div class="media-left"> <img class="media-object" src="img/g5.png" alt="small-properties-1"> </div>
              <div class="media-body">
                <h3 class="media-heading"> <a href="#">Sweet Family Home</a> </h3>
                <p>April 25, 2018</p>
                <div class="price"> $734,000 </div>
              </div>
            </div>
            <div class="media">
              <div class="media-left"> <img class="media-object" src="img/g5.png" alt="small-properties-2"> </div>
              <div class="media-body">
                <h3 class="media-heading"> <a href="#">Modern Family Home</a> </h3>
                <p>April 25, 2018</p>
                <div class="price"> $734,000 </div>
              </div>
            </div>
            <div class="media">
              <div class="media-left"> <img class="media-object" src="img/g5.png" alt="small-properties-3"> </div>
              <div class="media-body">
                <h3 class="media-heading"> <a href="#">Beautiful Single Home</a> </h3>
                <p>April 25, 2018</p>
                <div class="price"> $734,000 </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
          <div class="footer-item">
            <div class="main-title-2">
              <h1>Subscribe</h1>
            </div>
            <div class="newsletter clearfix">
              <p> Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id </p>
              <form action="#" method="post">
                <div class="form-group">
                  <input class="nsu-field btn-block" id="nsu-email-0" type="text" name="email" placeholder="Enter your Email Address" required="">
                </div>
                <div class="form-group mb-0">
                  <button type="submit" class="button-sm button-theme btn-block"> Subscribe </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>